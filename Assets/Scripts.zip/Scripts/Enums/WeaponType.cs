
namespace Kwalee.SimpleShootyTest
{
    public enum WeaponType
    {
        None,
        Pistol,
        ShotGun,
        MachineGun,
    }
}